''' 
*********************************
Project: Final Project
Names of Partners: Lina Fernandez and Therese Do
Description: Image Artist. Theme from Night
*********************************
'''

#import libraries
import PIL
import matplotlib.pyplot as plt
import os.path
import numpy as np
import PIL.ImageDraw

#Open files in the same folder
directory = os.path.dirname(os.path.abspath(__file__))
door_file = os.path.join(directory, 'dooor.jpg')
tiger_file = os.path.join(directory, 'tiger.jpg')
woman_file = os.path.join(directory, 'woman.jpg')
puzzle_file = os.path.join(directory, 'puzzle.png')
brain_file = os.path.join(directory, 'brain.jpg')

#opens and shows the image after running
#put it all in once place for easy access later
door = PIL.Image.open(door_file)
door2 = PIL.Image.open(door_file)
woman = PIL.Image.open(woman_file)
tiger = PIL.Image.open(tiger_file)
puzzle = PIL.Image.open(puzzle_file)
brain = PIL.Image.open(brain_file)

fig, ax = plt.subplots(1, 1)

#pastes the woman
wom = woman.resize((800, 500), PIL.Image.ANTIALIAS)
door.paste(wom, (195, 728))

#pastes the tiger
tig = tiger.crop((173,0,379,422))
tig2 = tig.resize((208, 483))
door.paste(tig2, (230, 136))

#paste the puzzle
puz=puzzle.resize((208,483))
door.paste(puz, (684, 140))

#adds a blue border over because it's peaceful colors
img_1 = np.array(door)
img = (img_1)
height = (img)
width = (img)
for r in range(62, 700):
    for c in range(40,498):
        if sum(img[r][c])>745:
            img[r][c]=[0,191,255]
    fig.canvas.draw
#Changes the colors [red and purple?] and adds patterns on the puzzle
for r in range (140, 626):
    for c in range(688, 889):
        if (r+c)/2 == 0 or (r+c) % 2 ==0:
            img[r][c] = [255, 0, 0]
    fig.canvas.draw
#shows the image
ax.imshow(img)
fig.show()