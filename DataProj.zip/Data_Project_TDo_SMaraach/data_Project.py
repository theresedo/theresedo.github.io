'''
*****************
Partners: Therese Do and Sarah Maraach
Project: Data Project on influenza and its effectiveness
*****************
'''

#import libraries
import matplotlib.pyplot as plt
import os.path
import numpy as np

def bar_graph():
    #empy lists are created to aggregate
    height_death = []
    height_vaccine = []
    years_deaths = []
    years_vaccine = []
    colors = ['#b19cd9', '#93dcc3', '#FFDFEF', '#CEF0FF','#c0c0c0','#fdfd96']
    #able to open and access files
    directory = os.path.dirname(os.path.abspath(__file__))
    filename = os.path.join(directory, 'influenza.csv')
    filevaccine = os.path.join(directory, 'vaccine.csv')
    datafile = open(filename, 'r')
    datavaccine = open(filevaccine, 'r')
    data = datafile.readlines()
    data_ = datavaccine.readlines()
    #iterates through lines in datafiles
    #For death bar graph
    for line in data[1:]: #omits line 0 because there isn't any data
        year, cause_of_death, amount_of_deaths = line.split(',')
        if 'Influenza' in cause_of_death:
            height_death += [amount_of_deaths]
            years_deaths += [year]
    #for vaccination bar graph
    for line in data_[1:]:
        years, vaccine = line.split(',')
        if '1999' in years:
            years_vaccine += [years]
            height_vaccine += [(vaccine)]
        if '2000' in years:
            years_vaccine += [years]
            height_vaccine += [(vaccine)]
        if '2009' in years:
            years_vaccine += [years]
            height_vaccine += [(vaccine)]
        if '2008' in years:
            years_vaccine += [years]
            height_vaccine += [(vaccine)]
        if '2012' in years:
            years_vaccine += [years]
            height_vaccine += [(vaccine)]
        if '2013' in years:
            years_vaccine += [years]
            height_vaccine += [(vaccine)]
    #creates bar graph for deaths due to influenza
    fig, axes = plt.subplots(1, 1)
    x_axis0 = np.arange(len(years_deaths))
    plt.xticks(x_axis0, years_deaths)
    plt.title('Influenza/Pneumonia Deaths')
    plt.xlabel('Years')
    plt.ylabel('Number of Deaths (People)')
    axes.bar(x_axis0, height_death, width = 0.8, bottom = 0, align='center', color = colors)
    fig.show()
    #creates second bar graph for vaccination amount
    fig1, ax = plt.subplots(1,1)
    x_axis1 = np.arange(len(years_vaccine))
    plt.xticks(x_axis1, years_vaccine)
    plt.title('Amount of Vaccinations')
    plt.xlabel('Years')
    plt.ylabel('Number of Vaccinations(Millions)')
    ax.bar(x_axis1, height_vaccine, width = 0.8, bottom = 0, align='center', color = colors)
    fig1.show()

    
#main
bar_graph()